username == "RowanNoodle";
Password == "123456" ;

function confirmar(){
var lgn = document.getElementById ('login').value;
var pwd = document.getElementById ('passwd').value;

if(lgn== username & pwd== Password){ alert ( '*peido*')
}
else{
    alert ('deu merda')
}

}